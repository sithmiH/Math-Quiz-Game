package com.example.quizgame

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class GameViewModel : ViewModel() {
    private val _score = MutableLiveData<Int>()
    val score: LiveData<Int>
        get() = _score

    private val _highScore = MutableLiveData<Int>()
    val highScore: LiveData<Int>
        get() = _highScore

    init {
        _score.value = 0
        _highScore.value = 0
    }

    fun updateScore(newScore: Int) {
        _score.value = newScore
    }

    fun updateHighScore(newHighScore: Int) {
        _highScore.value = newHighScore
    }
}